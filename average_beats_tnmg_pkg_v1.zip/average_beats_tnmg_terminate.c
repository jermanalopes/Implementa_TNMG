/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * average_beats_tnmg_terminate.c
 *
 * Code generation for function 'average_beats_tnmg_terminate'
 *
 */

/* Include files */
#include "average_beats_tnmg_terminate.h"
#include "average_beats_tnmg_data.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void average_beats_tnmg_terminate(void)
{
  /* (no terminate code required) */
  isInitialized_average_beats_tnmg = false;
}

/* End of code generation (average_beats_tnmg_terminate.c) */
