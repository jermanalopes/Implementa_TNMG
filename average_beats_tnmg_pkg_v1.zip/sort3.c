/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * sort3.c
 *
 * Code generation for function 'sort3'
 *
 */

/* Include files */
#include "sort3.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void sort3(double v1, double v2, double v3, int *b_j1, int *j2)
{
  if (v1 < v2) {
    if (v2 < v3) {
      *b_j1 = 1;
      *j2 = 2;
    } else if (v1 < v3) {
      *b_j1 = 1;
      *j2 = 3;
    } else {
      *b_j1 = 3;
      *j2 = 1;
    }
  } else if (v1 < v3) {
    *b_j1 = 2;
    *j2 = 1;
  } else if (v2 < v3) {
    *b_j1 = 2;
    *j2 = 3;
  } else {
    *b_j1 = 3;
    *j2 = 2;
  }
}

/* End of code generation (sort3.c) */
