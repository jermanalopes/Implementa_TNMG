/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * average_beats_tnmg.c
 *
 * Code generation for function 'average_beats_tnmg'
 *
 */

/* Include files */
#include "average_beats_tnmg.h"
#include "average_beats_tnmg_data.h"
#include "average_beats_tnmg_emxutil.h"
#include "average_beats_tnmg_initialize.h"
#include "average_beats_tnmg_rtwutil.h"
#include "average_beats_tnmg_types.h"
#include "diff.h"
#include "median.h"
#include "nanmean.h"
#include "nanmedian.h"
#include "nanvar.h"
#include "nullAssignment.h"
#include "power.h"
#include "rt_nonfinite.h"
#include "squeeze.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */
void average_beats_tnmg(const emxArray_real_T *ecg, emxArray_real_T *R_pos,
                        double fs, const emxArray_real_T *vcg,
                        double SNR_overall_data[], int SNR_overall_size[2],
                        double *SNR_overall_type)
{
  emxArray_boolean_T *very_bad_lead;
  emxArray_boolean_T *x;
  emxArray_int32_T *r2;
  emxArray_int32_T *r3;
  emxArray_int32_T *r4;
  emxArray_int8_T *group;
  emxArray_real_T *R_PosAtual;
  emxArray_real_T *SNR_median;
  emxArray_real_T *a;
  emxArray_real_T *b;
  emxArray_real_T *b_SNR_median;
  emxArray_real_T *b_b;
  emxArray_real_T *b_beats;
  emxArray_real_T *b_int;
  emxArray_real_T *beats;
  emxArray_real_T *beats_av;
  emxArray_real_T *beats_av_var;
  emxArray_real_T *c_beats;
  emxArray_real_T *d_beats;
  emxArray_real_T *err;
  emxArray_real_T *int0;
  emxArray_real_T *r;
  emxArray_real_T *r1;
  emxArray_real_T *y;
  double b_y[6];
  double dv[3];
  double err1;
  double err2;
  double mdc;
  double mediana_R;
  double offset;
  int b_i;
  int c_i;
  int i;
  int i1;
  int i2;
  int i3;
  int j;
  int loop_ub;
  int nx;
  int pos;
  int tam_R;
  int u1;
  signed char important_leads_data[3];
  signed char sizes_idx_0;
  boolean_T b_x[6];
  boolean_T beat_modified;
  boolean_T guard1 = false;
  (void)vcg;
  if (!isInitialized_average_beats_tnmg) {
    average_beats_tnmg_initialize();
  }
  /*  [in ms] zero if you do not want to correct */
  /*  threshold used to define if a lead signal is noisy or not */
  if (R_pos->size[1] < 2) {
    SNR_overall_size[0] = 1;
    SNR_overall_size[1] = 1;
    SNR_overall_data[0] = 0.0;
    *SNR_overall_type = 1.0;
    /*      SNR_median = zeros(size(ecg,1),1); */
    /*      SNR_hrv = NaN; */
  } else {
    emxInit_real_T(&beats, 3);
    emxInit_real_T(&R_PosAtual, 2);
    /*  Seta valores iniciais de offset (baseado na mediana dos picos R) */
    /*  SNR_overall = []; */
    /*  SNR_median=zeros(size(ecg,1),1); */
    *SNR_overall_type = 0.0;
    tam_R = R_pos->size[1];
    diff(R_pos, R_PosAtual);
    mediana_R = rt_roundd_snf(median(R_PosAtual) * 1.1);
    offset = rt_roundd_snf(mediana_R / 3.0);
    i = beats->size[0] * beats->size[1] * beats->size[2];
    beats->size[0] = R_pos->size[1];
    beats->size[1] = ecg->size[0];
    beats->size[2] = (int)mediana_R;
    emxEnsureCapacity_real_T(beats, i);
    loop_ub = ecg->size[0] * R_pos->size[1] * (int)mediana_R;
    for (i = 0; i < loop_ub; i++) {
      beats->data[i] = rtNaN;
    }
    if ((ecg->size[0] == 0) || (ecg->size[1] == 0)) {
      u1 = 0;
    } else {
      nx = ecg->size[0];
      u1 = ecg->size[1];
      if (nx > u1) {
        u1 = nx;
      }
    }
    i = R_PosAtual->size[0] * R_PosAtual->size[1];
    R_PosAtual->size[0] = 1;
    R_PosAtual->size[1] = R_pos->size[1] + 1;
    emxEnsureCapacity_real_T(R_PosAtual, i);
    loop_ub = R_pos->size[1];
    for (i = 0; i < loop_ub; i++) {
      R_PosAtual->data[i] = R_pos->data[i];
    }
    emxInit_int8_T(&group, 2);
    R_PosAtual->data[R_pos->size[1]] = u1;
    /* Acrescenta o length ao R_Pos */
    i = group->size[0] * group->size[1];
    group->size[0] = 1;
    group->size[1] = R_pos->size[1];
    emxEnsureCapacity_int8_T(group, i);
    loop_ub = R_pos->size[1];
    for (i = 0; i < loop_ub; i++) {
      group->data[i] = 1;
    }
    emxInit_real_T(&int0, 2);
    if (mediana_R - 1.0 < 0.0) {
      int0->size[0] = 1;
      int0->size[1] = 0;
    } else if (rtIsInf(mediana_R - 1.0) && (0.0 == mediana_R - 1.0)) {
      i = int0->size[0] * int0->size[1];
      int0->size[0] = 1;
      int0->size[1] = 1;
      emxEnsureCapacity_real_T(int0, i);
      int0->data[0] = rtNaN;
    } else {
      i = int0->size[0] * int0->size[1];
      int0->size[0] = 1;
      int0->size[1] = (int)(mediana_R - 1.0) + 1;
      emxEnsureCapacity_real_T(int0, i);
      loop_ub = (int)(mediana_R - 1.0);
      for (i = 0; i <= loop_ub; i++) {
        int0->data[i] = i;
      }
    }
    /*  Seleciona em torno das posiÃ§Ãµes de Picos R, int intervalos (valores)
     * para as 12 derivaÃ§Ãµes - ECG e VCG */
    /*  CÃ¡lculo dos picos R para o sinal ECG e VCG de cada uma das 12
     * derivaÃ§Ãµes */
    i = R_pos->size[1];
    loop_ub = int0->size[1];
    b_i = ecg->size[0];
    emxInit_real_T(&b_int, 2);
    emxInit_real_T(&beats_av_var, 1);
    emxInit_real_T(&b, 2);
    emxInit_boolean_T(&x, 2);
    for (c_i = 0; c_i < i; c_i++) {
      i1 = b_int->size[0] * b_int->size[1];
      b_int->size[0] = 1;
      b_int->size[1] = int0->size[1];
      emxEnsureCapacity_real_T(b_int, i1);
      err1 = R_PosAtual->data[c_i];
      for (i1 = 0; i1 < loop_ub; i1++) {
        b_int->data[i1] = ((err1 + int0->data[i1]) - offset) + 1.0;
      }
      /* Pega (int) valores de pos. em torno da pos. do R */
      i1 = x->size[0] * x->size[1];
      x->size[0] = 1;
      x->size[1] = b_int->size[1];
      emxEnsureCapacity_boolean_T(x, i1);
      err1 = R_PosAtual->data[c_i + 1] - offset / 20.0;
      pos = b_int->size[1];
      for (i1 = 0; i1 < pos; i1++) {
        err2 = b_int->data[i1];
        x->data[i1] = ((err2 > err1) || (err2 < 1.0));
      }
      nullAssignment(b_int, x);
      /* coloca nan para valores maiores que o valor definido */
      if (1 > b_int->size[1]) {
        pos = 0;
      } else {
        pos = b_int->size[1];
      }
      i1 = beats_av_var->size[0];
      beats_av_var->size[0] = b_int->size[1];
      emxEnsureCapacity_real_T(beats_av_var, i1);
      u1 = b_int->size[1];
      for (i1 = 0; i1 < u1; i1++) {
        beats_av_var->data[i1] = b_int->data[i1];
      }
      nx = beats->size[1];
      i1 = b->size[0] * b->size[1];
      b->size[0] = b_i;
      b->size[1] = beats_av_var->size[0];
      emxEnsureCapacity_real_T(b, i1);
      u1 = beats_av_var->size[0];
      for (i1 = 0; i1 < u1; i1++) {
        for (i2 = 0; i2 < b_i; i2++) {
          b->data[i2 + b->size[0] * i1] =
              ecg->data[i2 + ecg->size[0] * ((int)beats_av_var->data[i1] - 1)];
        }
      }
      u1 = beats->size[1];
      for (i1 = 0; i1 < pos; i1++) {
        for (i2 = 0; i2 < nx; i2++) {
          beats->data[(c_i + beats->size[0] * i2) +
                      beats->size[0] * beats->size[1] * i1] =
              b->data[i2 + u1 * i1];
        }
      }
      /* Para cada R de cada derivaÃ§Ã£o (pega int valores proximos a R) - ECG
       */
      /* Para cada R (pega int valores proximos para cada derivaÃ§Ã£o) - VCG */
    }
    emxInit_real_T(&beats_av, 2);
    /*  Calcula beats_av - batimentos mÃ©dios em relaÃ§Ã£o a beats  */
    /*  Calcula o batimento mÃ©dio do ECG */
    i = beats_av->size[0] * beats_av->size[1];
    beats_av->size[0] = ecg->size[0];
    beats_av->size[1] = (int)mediana_R;
    emxEnsureCapacity_real_T(beats_av, i);
    loop_ub = ecg->size[0] * (int)mediana_R;
    for (i = 0; i < loop_ub; i++) {
      beats_av->data[i] = 0.0;
    }
    i = ecg->size[0];
    emxInit_real_T(&b_beats, 3);
    emxInit_real_T(&r, 2);
    for (c_i = 0; c_i < i; c_i++) {
      loop_ub = beats->size[0];
      b_i = beats->size[2];
      i1 = b_beats->size[0] * b_beats->size[1] * b_beats->size[2];
      b_beats->size[0] = beats->size[0];
      b_beats->size[1] = 1;
      b_beats->size[2] = beats->size[2];
      emxEnsureCapacity_real_T(b_beats, i1);
      for (i1 = 0; i1 < b_i; i1++) {
        for (i2 = 0; i2 < loop_ub; i2++) {
          b_beats->data[i2 + b_beats->size[0] * i1] =
              beats->data[(i2 + beats->size[0] * c_i) +
                          beats->size[0] * beats->size[1] * i1];
        }
      }
      squeeze(b_beats, r);
      nanmedian(r, b_int);
      loop_ub = b_int->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        beats_av->data[c_i + beats_av->size[0] * i1] = b_int->data[i1];
      }
      /* Calcula a mediana de cada derivaÃ§Ã£o nos R picos detectados da
       * derivaÃ§Ã£o */
      /* mas em torno dos int valores do pico R  */
    }
    /*  check if there is an offset in beat detections */
    /* %% Analisar a diferenÃ§a entre a potÃªncia do sinal (beats - beats_av) */
    beat_modified = false;
    mdc = rt_roundd_snf(9.0 / fs * 1000.0);
    i1 = R_pos->size[1];
    emxInit_real_T(&y, 2);
    emxInit_real_T(&a, 2);
    emxInit_real_T(&r1, 2);
    emxInit_real_T(&c_beats, 3);
    for (c_i = 0; c_i < i1; c_i++) {
      mediana_R = rtInf;
      pos = 0;
      i2 = (int)mdc;
      for (j = 0; j < i2; j++) {
        /* Calcula a diferenÃ§a ao quadrado de beats e beats_av */
        /* err1 = DiferenÃ§a ao Â² entre beats e beats_av das 3 DerivaÃ§Ãµes em
         * um deslocamento de */
        /* janela tamanho mdc - Elimina os NaN iniciais e finais */
        /*              errteste(j)=
         * nanmean(nanmean((squeeze(beats(i,1:3,j:end))-beats_av(1:3,1:(end-j+1))).^2,2));
         */
        if (j + 1U > (unsigned int)beats->size[2]) {
          i3 = 0;
          nx = 0;
        } else {
          i3 = j;
          nx = beats->size[2];
        }
        u1 = c_beats->size[0] * c_beats->size[1] * c_beats->size[2];
        c_beats->size[0] = 1;
        c_beats->size[1] = 3;
        loop_ub = nx - i3;
        c_beats->size[2] = loop_ub;
        emxEnsureCapacity_real_T(c_beats, u1);
        for (nx = 0; nx < loop_ub; nx++) {
          u1 = i3 + nx;
          c_beats->data[3 * nx] =
              beats->data[c_i + beats->size[0] * beats->size[1] * u1];
          c_beats->data[3 * nx + 1] =
              beats->data[(c_i + beats->size[0]) +
                          beats->size[0] * beats->size[1] * u1];
          c_beats->data[3 * nx + 2] =
              beats->data[(c_i + beats->size[0] * 2) +
                          beats->size[0] * beats->size[1] * u1];
        }
        b_squeeze(c_beats, r1);
        i3 = a->size[0] * a->size[1];
        a->size[0] = r1->size[0];
        a->size[1] = r1->size[1];
        emxEnsureCapacity_real_T(a, i3);
        loop_ub = r1->size[1];
        for (i3 = 0; i3 < loop_ub; i3++) {
          b_i = r1->size[0];
          for (nx = 0; nx < b_i; nx++) {
            a->data[nx + 3 * i3] = r1->data[nx + r1->size[0] * i3] -
                                   beats_av->data[nx + beats_av->size[0] * i3];
          }
        }
        i3 = y->size[0] * y->size[1];
        y->size[0] = 3;
        y->size[1] = a->size[1];
        emxEnsureCapacity_real_T(y, i3);
        nx = 3 * a->size[1];
        for (loop_ub = 0; loop_ub < nx; loop_ub++) {
          y->data[loop_ub] = a->data[loop_ub] * a->data[loop_ub];
        }
        nanmean(y, dv);
        err1 = b_nanmean(dv);
        /* err2 = err1 - inverte o deslocamento da janela mdc */
        i3 = (int)((double)beats->size[2] - ((double)j + 1.0));
        if (1 > i3 + 1) {
          loop_ub = -1;
        } else {
          loop_ub = i3;
        }
        if (j + 1U > (unsigned int)beats_av->size[1]) {
          i3 = 0;
        } else {
          i3 = j;
        }
        nx = c_beats->size[0] * c_beats->size[1] * c_beats->size[2];
        c_beats->size[0] = 1;
        c_beats->size[1] = 3;
        c_beats->size[2] = loop_ub + 1;
        emxEnsureCapacity_real_T(c_beats, nx);
        for (nx = 0; nx <= loop_ub; nx++) {
          c_beats->data[3 * nx] =
              beats->data[c_i + beats->size[0] * beats->size[1] * nx];
          c_beats->data[3 * nx + 1] =
              beats->data[(c_i + beats->size[0]) +
                          beats->size[0] * beats->size[1] * nx];
          c_beats->data[3 * nx + 2] =
              beats->data[(c_i + beats->size[0] * 2) +
                          beats->size[0] * beats->size[1] * nx];
        }
        b_squeeze(c_beats, r1);
        nx = a->size[0] * a->size[1];
        a->size[0] = r1->size[0];
        a->size[1] = r1->size[1];
        emxEnsureCapacity_real_T(a, nx);
        loop_ub = r1->size[1];
        for (nx = 0; nx < loop_ub; nx++) {
          b_i = r1->size[0];
          for (u1 = 0; u1 < b_i; u1++) {
            a->data[u1 + 3 * nx] =
                r1->data[u1 + r1->size[0] * nx] -
                beats_av->data[u1 + beats_av->size[0] * (i3 + nx)];
          }
        }
        i3 = y->size[0] * y->size[1];
        y->size[0] = 3;
        y->size[1] = a->size[1];
        emxEnsureCapacity_real_T(y, i3);
        nx = 3 * a->size[1];
        for (loop_ub = 0; loop_ub < nx; loop_ub++) {
          y->data[loop_ub] = a->data[loop_ub] * a->data[loop_ub];
        }
        nanmean(y, dv);
        err2 = b_nanmean(dv);
        if (err1 < mediana_R) {
          mediana_R = err1;
          pos = j;
        }
        /* Guarda a pos da janela mdc para o menor erro */
        if (err2 < mediana_R) {
          mediana_R = err2;
          pos = -j;
        }
      }
      if (pos != 0) {
        /* atualiza o tamanho do int */
        i2 = b_int->size[0] * b_int->size[1];
        b_int->size[0] = 1;
        b_int->size[1] = int0->size[1];
        emxEnsureCapacity_real_T(b_int, i2);
        err1 = R_PosAtual->data[c_i] + (double)pos;
        loop_ub = int0->size[1];
        for (i2 = 0; i2 < loop_ub; i2++) {
          b_int->data[i2] = (err1 + int0->data[i2]) - offset;
        }
        i2 = x->size[0] * x->size[1];
        x->size[0] = 1;
        x->size[1] = b_int->size[1];
        emxEnsureCapacity_boolean_T(x, i2);
        err1 = R_PosAtual->data[c_i + 1] - offset / 20.0;
        loop_ub = b_int->size[1];
        for (i2 = 0; i2 < loop_ub; i2++) {
          err2 = b_int->data[i2];
          x->data[i2] = ((err2 > err1) || (err2 < 1.0));
        }
        nullAssignment(b_int, x);
        /* coloca nan para valores maiores que o valor definido */
        i2 = beats_av_var->size[0];
        beats_av_var->size[0] = b_int->size[1];
        emxEnsureCapacity_real_T(beats_av_var, i2);
        loop_ub = b_int->size[1];
        for (i2 = 0; i2 < loop_ub; i2++) {
          beats_av_var->data[i2] = b_int->data[i2];
        }
        nx = beats->size[1];
        loop_ub = ecg->size[0];
        i2 = b->size[0] * b->size[1];
        b->size[0] = ecg->size[0];
        b->size[1] = beats_av_var->size[0];
        emxEnsureCapacity_real_T(b, i2);
        b_i = beats_av_var->size[0];
        for (i2 = 0; i2 < b_i; i2++) {
          for (i3 = 0; i3 < loop_ub; i3++) {
            b->data[i3 + b->size[0] * i2] =
                ecg->data[i3 +
                          ecg->size[0] * ((int)beats_av_var->data[i2] - 1)];
          }
        }
        u1 = beats->size[1];
        if (1 > b_int->size[1]) {
          loop_ub = 0;
        } else {
          loop_ub = b_int->size[1];
        }
        for (i2 = 0; i2 < loop_ub; i2++) {
          for (i3 = 0; i3 < nx; i3++) {
            beats->data[(c_i + beats->size[0] * i3) +
                        beats->size[0] * beats->size[1] * i2] =
                b->data[i3 + u1 * i2];
          }
        }
        beat_modified = true;
        R_pos->data[c_i] += (double)pos;
      }
    }
    emxFree_real_T(&c_beats);
    emxFree_real_T(&r1);
    emxFree_real_T(&a);
    emxFree_real_T(&y);
    emxFree_real_T(&int0);
    emxFree_real_T(&R_PosAtual);
    if (beat_modified) {
      /*  Recalcular o valor da mediana dos batimentos para o novo intervalo */
      for (c_i = 0; c_i < i; c_i++) {
        loop_ub = beats->size[0];
        b_i = beats->size[2];
        i1 = b_beats->size[0] * b_beats->size[1] * b_beats->size[2];
        b_beats->size[0] = beats->size[0];
        b_beats->size[1] = 1;
        b_beats->size[2] = beats->size[2];
        emxEnsureCapacity_real_T(b_beats, i1);
        for (i1 = 0; i1 < b_i; i1++) {
          for (i2 = 0; i2 < loop_ub; i2++) {
            b_beats->data[i2 + b_beats->size[0] * i1] =
                beats->data[(i2 + beats->size[0] * c_i) +
                            beats->size[0] * beats->size[1] * i1];
          }
        }
        squeeze(b_beats, r);
        nanmedian(r, b_int);
        loop_ub = b_int->size[1];
        for (i1 = 0; i1 < loop_ub; i1++) {
          beats_av->data[c_i + beats_av->size[0] * i1] = b_int->data[i1];
        }
      }
    }
    emxInit_real_T(&err, 2);
    /*  redefine average after discarding bad beats and define groups of beats
     */
    /*  DiferenÃ§a entre  */
    nanvar(beats_av, beats_av_var);
    /* Calcula variÃ¢ncia de beats_av por derivaÃ§Ã£o dos int valores */
    i1 = err->size[0] * err->size[1];
    err->size[0] = ecg->size[0];
    err->size[1] = tam_R;
    emxEnsureCapacity_real_T(err, i1);
    loop_ub = ecg->size[0] * tam_R;
    for (i1 = 0; i1 < loop_ub; i1++) {
      err->data[i1] = 0.0;
    }
    emxInit_real_T(&SNR_median, 1);
    emxInit_real_T(&d_beats, 3);
    emxInit_real_T(&b_b, 2);
    for (c_i = 0; c_i < tam_R; c_i++) {
      loop_ub = beats->size[1];
      b_i = beats->size[2];
      i1 = d_beats->size[0] * d_beats->size[1] * d_beats->size[2];
      d_beats->size[0] = 1;
      d_beats->size[1] = beats->size[1];
      d_beats->size[2] = beats->size[2];
      emxEnsureCapacity_real_T(d_beats, i1);
      for (i1 = 0; i1 < b_i; i1++) {
        for (i2 = 0; i2 < loop_ub; i2++) {
          d_beats->data[i2 + d_beats->size[1] * i1] =
              beats->data[(c_i + beats->size[0] * i2) +
                          beats->size[0] * beats->size[1] * i1];
        }
      }
      c_squeeze(d_beats, b);
      /* Por pico R - Pega os int valores das 12 DerivaÃ§Ãµes */
      i1 = b_b->size[0] * b_b->size[1];
      b_b->size[0] = b->size[0];
      b_b->size[1] = b->size[1];
      emxEnsureCapacity_real_T(b_b, i1);
      loop_ub = b->size[0] * b->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        b_b->data[i1] = b->data[i1] - beats_av->data[i1];
      }
      power(b_b, r);
      c_nanmean(r, SNR_median);
      loop_ub = SNR_median->size[0];
      for (i1 = 0; i1 < loop_ub; i1++) {
        err->data[i1 + err->size[0] * c_i] = SNR_median->data[i1];
      }
      /* in the following lines I am assuming that the ECG is in millivolts */
      /* Analisa os 6 valores iniciais do erro e compara com os valores dos */
      /* beats_av_var. Se tiver mais de 3 valores maiores  */
      for (loop_ub = 0; loop_ub < 6; loop_ub++) {
        b_y[loop_ub] = fabs(b->data[loop_ub + b->size[0]]);
        b_x[loop_ub] = (err->data[loop_ub + err->size[0] * c_i] <
                        beats_av_var->data[loop_ub]);
      }
      u1 = b_x[0];
      for (loop_ub = 0; loop_ub < 5; loop_ub++) {
        u1 += b_x[loop_ub + 1];
      }
      for (b_i = 0; b_i < 6; b_i++) {
        b_x[b_i] = (0.0 * b_y[b_i] < 10000.0);
      }
      nx = b_x[0];
      for (loop_ub = 0; loop_ub < 5; loop_ub++) {
        nx += b_x[loop_ub + 1];
      }
      group->data[c_i] = (signed char)((u1 > 3) && (nx > 3));
      /*  testar b(1:6,2) */
    }
    emxFree_real_T(&b_b);
    emxInit_int32_T(&r2, 2);
    for (c_i = 0; c_i < i; c_i++) {
      u1 = group->size[1] - 1;
      nx = 0;
      for (b_i = 0; b_i <= u1; b_i++) {
        if (group->data[b_i] == 1) {
          nx++;
        }
      }
      i1 = r2->size[0] * r2->size[1];
      r2->size[0] = 1;
      r2->size[1] = nx;
      emxEnsureCapacity_int32_T(r2, i1);
      nx = 0;
      for (b_i = 0; b_i <= u1; b_i++) {
        if (group->data[b_i] == 1) {
          r2->data[nx] = b_i + 1;
          nx++;
        }
      }
      loop_ub = beats->size[2];
      i1 = b_beats->size[0] * b_beats->size[1] * b_beats->size[2];
      b_beats->size[0] = r2->size[1];
      b_beats->size[1] = 1;
      b_beats->size[2] = beats->size[2];
      emxEnsureCapacity_real_T(b_beats, i1);
      for (i1 = 0; i1 < loop_ub; i1++) {
        b_i = r2->size[1];
        for (i2 = 0; i2 < b_i; i2++) {
          b_beats->data[i2 + b_beats->size[0] * i1] =
              beats->data[((r2->data[i2] + beats->size[0] * c_i) +
                           beats->size[0] * beats->size[1] * i1) -
                          1];
        }
      }
      squeeze(b_beats, r);
      nanmedian(r, b_int);
      loop_ub = b_int->size[1];
      for (i1 = 0; i1 < loop_ub; i1++) {
        beats_av->data[c_i + beats_av->size[0] * i1] = b_int->data[i1];
      }
    }
    emxFree_real_T(&b_beats);
    emxFree_int32_T(&r2);
    emxFree_real_T(&b_int);
    /*  compute SNR  */
    /*  the overall_type field has the following meaninig: */
    /*  0 = good ecg recording */
    /*  1 = bad ecg recording due to overall poor quality */
    /*  2 = bad 0ecg recording due to many leads having very poor quality  */
    /*  3 = bad ecg recording due to large part of tracing being without signal
     */
    /*  max fraction of the tracing that I accept to be a flat line  */
    /* mudanÃ§a */
    /*  maximum number of VERY bad leads (i.e SNR<SNR_threshold/3) that I can
     * accept */
    /*  SNR.overall_type = 2 - Falta de traçado em algumas derivaÃ§Ãµes */
    /*  A diferenÃ§a do ultimo R com o primeiro divido pelo total < 0.35 */
    loop_ub = ecg->size[1];
    i = x->size[0] * x->size[1];
    x->size[0] = 1;
    x->size[1] = ecg->size[1];
    emxEnsureCapacity_boolean_T(x, i);
    for (i = 0; i < loop_ub; i++) {
      x->data[i] = rtIsNaN(ecg->data[ecg->size[0] * i]);
    }
    i = x->size[0] * x->size[1];
    x->size[0] = 1;
    emxEnsureCapacity_boolean_T(x, i);
    loop_ub = x->size[1] - 1;
    for (i = 0; i <= loop_ub; i++) {
      x->data[i] = !x->data[i];
    }
    nx = x->size[1];
    if (x->size[1] == 0) {
      u1 = 0;
    } else {
      u1 = x->data[0];
      for (loop_ub = 2; loop_ub <= nx; loop_ub++) {
        u1 += x->data[loop_ub - 1];
      }
    }
    emxFree_boolean_T(&x);
    if ((R_pos->data[R_pos->size[1] - 1] - R_pos->data[0]) / (double)u1 <
        0.35) {
      SNR_overall_size[0] = 1;
      SNR_overall_size[1] = 1;
      SNR_overall_data[0] = 0.0;
      *SNR_overall_type = 3.0;
      /* SNR_overall_type=1;  */
    } else {
      i = err->size[0] * err->size[1];
      err->size[0] = ecg->size[0];
      err->size[1] = tam_R;
      emxEnsureCapacity_real_T(err, i);
      loop_ub = ecg->size[0] * tam_R;
      for (i = 0; i < loop_ub; i++) {
        err->data[i] = 0.0;
      }
      /* Zera os erros e recalcula */
      for (c_i = 0; c_i < tam_R; c_i++) {
        /* Calcula a media da dif entre beats e beats_av */
        loop_ub = beats->size[1];
        b_i = beats->size[2];
        i = d_beats->size[0] * d_beats->size[1] * d_beats->size[2];
        d_beats->size[0] = 1;
        d_beats->size[1] = beats->size[1];
        d_beats->size[2] = beats->size[2];
        emxEnsureCapacity_real_T(d_beats, i);
        for (i = 0; i < b_i; i++) {
          for (i1 = 0; i1 < loop_ub; i1++) {
            d_beats->data[i1 + d_beats->size[1] * i] =
                beats->data[(c_i + beats->size[0] * i1) +
                            beats->size[0] * beats->size[1] * i];
          }
        }
        c_squeeze(d_beats, r);
        i = b->size[0] * b->size[1];
        b->size[0] = r->size[0];
        b->size[1] = r->size[1];
        emxEnsureCapacity_real_T(b, i);
        loop_ub = r->size[0] * r->size[1];
        for (i = 0; i < loop_ub; i++) {
          b->data[i] = r->data[i] - beats_av->data[i];
        }
        power(b, r);
        c_nanmean(r, SNR_median);
        loop_ub = SNR_median->size[0];
        for (i = 0; i < loop_ub; i++) {
          err->data[i + err->size[0] * c_i] = SNR_median->data[i];
        }
      }
      /* Calculo SNR */
      u1 = group->size[1] - 1;
      nx = 0;
      for (c_i = 0; c_i <= u1; c_i++) {
        if (group->data[c_i] == 1) {
          nx++;
        }
      }
      emxInit_int32_T(&r3, 2);
      i = r3->size[0] * r3->size[1];
      r3->size[0] = 1;
      r3->size[1] = nx;
      emxEnsureCapacity_int32_T(r3, i);
      nx = 0;
      for (c_i = 0; c_i <= u1; c_i++) {
        if (group->data[c_i] == 1) {
          r3->data[nx] = c_i + 1;
          nx++;
        }
      }
      nanvar(beats_av, SNR_median);
      loop_ub = err->size[0];
      i = b->size[0] * b->size[1];
      b->size[0] = err->size[0];
      b->size[1] = r3->size[1];
      emxEnsureCapacity_real_T(b, i);
      b_i = r3->size[1];
      for (i = 0; i < b_i; i++) {
        for (i1 = 0; i1 < loop_ub; i1++) {
          b->data[i1 + b->size[0] * i] =
              err->data[i1 + err->size[0] * (r3->data[i] - 1)];
        }
      }
      emxFree_int32_T(&r3);
      b_nanmedian(b, beats_av_var);
      loop_ub = SNR_median->size[0];
      for (i = 0; i < loop_ub; i++) {
        SNR_median->data[i] /= beats_av_var->data[i];
      }
      emxInit_boolean_T(&very_bad_lead, 1);
      i = very_bad_lead->size[0];
      very_bad_lead->size[0] = SNR_median->size[0];
      emxEnsureCapacity_boolean_T(very_bad_lead, i);
      loop_ub = SNR_median->size[0];
      for (i = 0; i < loop_ub; i++) {
        very_bad_lead->data[i] = rtIsNaN(SNR_median->data[i]);
      }
      u1 = very_bad_lead->size[0] - 1;
      nx = 0;
      for (c_i = 0; c_i <= u1; c_i++) {
        if (very_bad_lead->data[c_i]) {
          nx++;
        }
      }
      emxInit_int32_T(&r4, 1);
      i = r4->size[0];
      r4->size[0] = nx;
      emxEnsureCapacity_int32_T(r4, i);
      nx = 0;
      for (c_i = 0; c_i <= u1; c_i++) {
        if (very_bad_lead->data[c_i]) {
          r4->data[nx] = c_i + 1;
          nx++;
        }
      }
      loop_ub = r4->size[0];
      for (i = 0; i < loop_ub; i++) {
        SNR_median->data[r4->data[i] - 1] = 0.0;
      }
      emxFree_int32_T(&r4);
      /* NaN ? flat line */
      if (SNR_median->size[0] == 12) {
        /* Verifica se o exame ta completo */
        /*  compute median giving more weight to DI DII and AVf */
        nx = 3;
        u1 = 1;
        important_leads_data[0] = 1;
        important_leads_data[1] = 2;
        important_leads_data[2] = 6;
      } else {
        nx = 0;
        u1 = 0;
      }
      /*  Calculo SNR.overall type 0, 1 e 3 */
      if (SNR_median->size[0] != 0) {
        pos = SNR_median->size[0];
      } else {
        pos = 0;
      }
      if ((nx != 0) && (u1 != 0)) {
        sizes_idx_0 = (signed char)nx;
      } else {
        sizes_idx_0 = 0;
      }
      emxInit_real_T(&b_SNR_median, 2);
      i = b_SNR_median->size[0] * b_SNR_median->size[1];
      b_SNR_median->size[0] = pos + sizes_idx_0;
      b_SNR_median->size[1] = 1;
      emxEnsureCapacity_real_T(b_SNR_median, i);
      for (i = 0; i < 1; i++) {
        for (i1 = 0; i1 < pos; i1++) {
          b_SNR_median->data[i1] = SNR_median->data[i1];
        }
      }
      loop_ub = sizes_idx_0;
      for (i = 0; i < 1; i++) {
        for (i1 = 0; i1 < loop_ub; i1++) {
          b_SNR_median->data[i1 + pos] =
              SNR_median->data[important_leads_data[i1] - 1];
        }
      }
      b_median(b_SNR_median, SNR_overall_data, SNR_overall_size);
      /*  Coloca como relevante das der (1, 2, 6) */
      /*      if(SNR_overall < SNR_threshold) */
      /*          SNR_overall = 1; */
      /*      else */
      /*           SNR_overall = 0; */
      /*      end */
      /*      SNR_overall_type=double(SNR_overall<SNR_threshold); %0 means good
       * 1 means bad quality. SNR_threshold definido no inicio e = 7 */
      i = very_bad_lead->size[0];
      very_bad_lead->size[0] = SNR_median->size[0];
      emxEnsureCapacity_boolean_T(very_bad_lead, i);
      loop_ub = SNR_median->size[0];
      emxFree_real_T(&b_SNR_median);
      for (i = 0; i < loop_ub; i++) {
        very_bad_lead->data[i] = (SNR_median->data[i] < 1.5);
      }
      nx = very_bad_lead->size[0];
      if (very_bad_lead->size[0] == 0) {
        u1 = 0;
      } else {
        u1 = very_bad_lead->data[0];
        for (loop_ub = 2; loop_ub <= nx; loop_ub++) {
          u1 += very_bad_lead->data[loop_ub - 1];
        }
      }
      guard1 = false;
      if ((u1 > 3) || very_bad_lead->data[1] ||
          (very_bad_lead->data[0] && very_bad_lead->data[5])) {
        guard1 = true;
      } else {
        i = very_bad_lead->size[0];
        very_bad_lead->size[0] = SNR_median->size[0];
        emxEnsureCapacity_boolean_T(very_bad_lead, i);
        loop_ub = SNR_median->size[0];
        for (i = 0; i < loop_ub; i++) {
          very_bad_lead->data[i] = (SNR_median->data[i] <= 0.2);
        }
        nx = very_bad_lead->size[0];
        if (very_bad_lead->size[0] == 0) {
          u1 = 0;
        } else {
          u1 = very_bad_lead->data[0];
          for (loop_ub = 2; loop_ub <= nx; loop_ub++) {
            u1 += very_bad_lead->data[loop_ub - 1];
          }
        }
        if (u1 >= 1) {
          guard1 = true;
        }
      }
      if (guard1) {
        SNR_overall_size[0] = 1;
        SNR_overall_size[1] = 1;
        SNR_overall_data[0] = 0.0;
        *SNR_overall_type = 2.0;
        /* SNR_overall_type=1;  */
      }
      emxFree_boolean_T(&very_bad_lead);
    }
    emxFree_real_T(&r);
    emxFree_real_T(&d_beats);
    emxFree_real_T(&err);
    emxFree_real_T(&SNR_median);
    emxFree_real_T(&b);
    emxFree_real_T(&beats_av_var);
    emxFree_real_T(&beats_av);
    emxFree_int8_T(&group);
    emxFree_real_T(&beats);
    /*  compute average vcg */
  }
}

/* End of code generation (average_beats_tnmg.c) */
