/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * sort3.h
 *
 * Code generation for function 'sort3'
 *
 */

#ifndef SORT3_H
#define SORT3_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
void sort3(double v1, double v2, double v3, int *b_j1, int *j2);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (sort3.h) */
