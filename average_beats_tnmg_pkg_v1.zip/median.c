/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * median.c
 *
 * Code generation for function 'median'
 *
 */

/* Include files */
#include "median.h"
#include "average_beats_tnmg_emxutil.h"
#include "average_beats_tnmg_types.h"
#include "quickselect.h"
#include "rt_nonfinite.h"
#include "sort3.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void b_median(const emxArray_real_T *x, double y_data[], int y_size[2])
{
  emxArray_real_T *v;
  double b;
  double m;
  int a__6;
  int exitg1;
  int ilast;
  int loop_ub;
  int midm1;
  int vlen;
  vlen = x->size[0];
  y_size[0] = 1;
  y_size[1] = x->size[1];
  if ((x->size[0] == 0) || (x->size[1] == 0)) {
    loop_ub = x->size[1];
    y_size[0] = 1;
    y_size[1] = x->size[1];
    if (0 <= loop_ub - 1) {
      y_data[0] = rtNaN;
    }
  } else {
    emxInit_real_T(&v, 1);
    loop_ub = x->size[0];
    a__6 = v->size[0];
    v->size[0] = x->size[0];
    emxEnsureCapacity_real_T(v, a__6);
    for (a__6 = 0; a__6 < loop_ub; a__6++) {
      v->data[a__6] = x->data[a__6];
    }
    loop_ub = 0;
    do {
      exitg1 = 0;
      if (loop_ub <= vlen - 1) {
        if (rtIsNaN(x->data[loop_ub])) {
          y_data[0] = rtNaN;
          exitg1 = 1;
        } else {
          loop_ub++;
        }
      } else {
        if (vlen <= 4) {
          if (vlen == 0) {
            y_data[0] = rtNaN;
          } else if (vlen == 1) {
            y_data[0] = x->data[0];
          } else if (vlen == 2) {
            if (((x->data[0] < 0.0) != (x->data[1] < 0.0)) ||
                rtIsInf(x->data[0])) {
              y_data[0] = (x->data[0] + x->data[1]) / 2.0;
            } else {
              y_data[0] = x->data[0] + (x->data[1] - x->data[0]) / 2.0;
            }
          } else if (vlen == 3) {
            sort3(x->data[0], x->data[1], x->data[2], &loop_ub, &ilast);
            y_data[0] = x->data[ilast - 1];
          } else {
            if (x->data[0] < x->data[1]) {
              if (x->data[1] < x->data[2]) {
                loop_ub = 0;
                ilast = 1;
                a__6 = 2;
              } else if (x->data[0] < x->data[2]) {
                loop_ub = 0;
                ilast = 2;
                a__6 = 1;
              } else {
                loop_ub = 2;
                ilast = 0;
                a__6 = 1;
              }
            } else if (x->data[0] < x->data[2]) {
              loop_ub = 1;
              ilast = 0;
              a__6 = 2;
            } else if (x->data[1] < x->data[2]) {
              loop_ub = 1;
              ilast = 2;
              a__6 = 0;
            } else {
              loop_ub = 2;
              ilast = 1;
              a__6 = 0;
            }
            if (x->data[loop_ub] < x->data[3]) {
              if (x->data[3] < x->data[a__6]) {
                if (((x->data[ilast] < 0.0) != (x->data[3] < 0.0)) ||
                    rtIsInf(x->data[ilast])) {
                  y_data[0] = (x->data[ilast] + x->data[3]) / 2.0;
                } else {
                  y_data[0] =
                      x->data[ilast] + (x->data[3] - x->data[ilast]) / 2.0;
                }
              } else if (((x->data[ilast] < 0.0) != (x->data[a__6] < 0.0)) ||
                         rtIsInf(x->data[ilast])) {
                y_data[0] = (x->data[ilast] + x->data[a__6]) / 2.0;
              } else {
                y_data[0] =
                    x->data[ilast] + (x->data[a__6] - x->data[ilast]) / 2.0;
              }
            } else if (((x->data[loop_ub] < 0.0) != (x->data[ilast] < 0.0)) ||
                       rtIsInf(x->data[loop_ub])) {
              y_data[0] = (x->data[loop_ub] + x->data[ilast]) / 2.0;
            } else {
              y_data[0] =
                  x->data[loop_ub] + (x->data[ilast] - x->data[loop_ub]) / 2.0;
            }
          }
        } else {
          midm1 = vlen >> 1;
          if ((vlen & 1) == 0) {
            quickselect(v, midm1 + 1, vlen, &m, &loop_ub, &ilast);
            y_data[0] = m;
            if (midm1 < loop_ub) {
              quickselect(v, midm1, ilast - 1, &b, &loop_ub, &a__6);
              if (((m < 0.0) != (b < 0.0)) || rtIsInf(m)) {
                y_data[0] = (m + b) / 2.0;
              } else {
                y_data[0] = m + (b - m) / 2.0;
              }
            }
          } else {
            quickselect(v, midm1 + 1, vlen, &y_data[0], &loop_ub, &a__6);
          }
        }
        exitg1 = 1;
      }
    } while (exitg1 == 0);
    emxFree_real_T(&v);
  }
}

double median(const emxArray_real_T *x)
{
  emxArray_real_T *a__4;
  double b;
  double y;
  int a__6;
  int exitg1;
  int ilast;
  int k;
  int midm1;
  int vlen;
  vlen = x->size[1];
  if (x->size[1] == 0) {
    y = rtNaN;
  } else {
    k = 0;
    emxInit_real_T(&a__4, 2);
    do {
      exitg1 = 0;
      if (k <= vlen - 1) {
        if (rtIsNaN(x->data[k])) {
          y = rtNaN;
          exitg1 = 1;
        } else {
          k++;
        }
      } else {
        if (vlen <= 4) {
          if (vlen == 0) {
            y = rtNaN;
          } else if (vlen == 1) {
            y = x->data[0];
          } else if (vlen == 2) {
            if (((x->data[0] < 0.0) != (x->data[1] < 0.0)) ||
                rtIsInf(x->data[0])) {
              y = (x->data[0] + x->data[1]) / 2.0;
            } else {
              y = x->data[0] + (x->data[1] - x->data[0]) / 2.0;
            }
          } else if (vlen == 3) {
            sort3(x->data[0], x->data[1], x->data[2], &k, &ilast);
            y = x->data[ilast - 1];
          } else {
            if (x->data[0] < x->data[1]) {
              if (x->data[1] < x->data[2]) {
                k = 0;
                ilast = 1;
                a__6 = 2;
              } else if (x->data[0] < x->data[2]) {
                k = 0;
                ilast = 2;
                a__6 = 1;
              } else {
                k = 2;
                ilast = 0;
                a__6 = 1;
              }
            } else if (x->data[0] < x->data[2]) {
              k = 1;
              ilast = 0;
              a__6 = 2;
            } else if (x->data[1] < x->data[2]) {
              k = 1;
              ilast = 2;
              a__6 = 0;
            } else {
              k = 2;
              ilast = 1;
              a__6 = 0;
            }
            if (x->data[k] < x->data[3]) {
              if (x->data[3] < x->data[a__6]) {
                if (((x->data[ilast] < 0.0) != (x->data[3] < 0.0)) ||
                    rtIsInf(x->data[ilast])) {
                  y = (x->data[ilast] + x->data[3]) / 2.0;
                } else {
                  y = x->data[ilast] + (x->data[3] - x->data[ilast]) / 2.0;
                }
              } else if (((x->data[ilast] < 0.0) != (x->data[a__6] < 0.0)) ||
                         rtIsInf(x->data[ilast])) {
                y = (x->data[ilast] + x->data[a__6]) / 2.0;
              } else {
                y = x->data[ilast] + (x->data[a__6] - x->data[ilast]) / 2.0;
              }
            } else if (((x->data[k] < 0.0) != (x->data[ilast] < 0.0)) ||
                       rtIsInf(x->data[k])) {
              y = (x->data[k] + x->data[ilast]) / 2.0;
            } else {
              y = x->data[k] + (x->data[ilast] - x->data[k]) / 2.0;
            }
          }
        } else {
          midm1 = vlen >> 1;
          if ((vlen & 1) == 0) {
            a__6 = a__4->size[0] * a__4->size[1];
            a__4->size[0] = 1;
            a__4->size[1] = x->size[1];
            emxEnsureCapacity_real_T(a__4, a__6);
            k = x->size[1];
            for (a__6 = 0; a__6 < k; a__6++) {
              a__4->data[a__6] = x->data[a__6];
            }
            quickselect(a__4, midm1 + 1, vlen, &y, &k, &ilast);
            if (midm1 < k) {
              quickselect(a__4, midm1, ilast - 1, &b, &k, &a__6);
              if (((y < 0.0) != (b < 0.0)) || rtIsInf(y)) {
                y = (y + b) / 2.0;
              } else {
                y += (b - y) / 2.0;
              }
            }
          } else {
            a__6 = a__4->size[0] * a__4->size[1];
            a__4->size[0] = 1;
            a__4->size[1] = x->size[1];
            emxEnsureCapacity_real_T(a__4, a__6);
            k = x->size[1];
            for (a__6 = 0; a__6 < k; a__6++) {
              a__4->data[a__6] = x->data[a__6];
            }
            quickselect(a__4, midm1 + 1, vlen, &y, &k, &a__6);
          }
        }
        exitg1 = 1;
      }
    } while (exitg1 == 0);
    emxFree_real_T(&a__4);
  }
  return y;
}

/* End of code generation (median.c) */
