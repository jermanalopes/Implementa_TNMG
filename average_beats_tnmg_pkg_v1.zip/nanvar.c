/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * nanvar.c
 *
 * Code generation for function 'nanvar'
 *
 */

/* Include files */
#include "nanvar.h"
#include "average_beats_tnmg_emxutil.h"
#include "average_beats_tnmg_types.h"
#include "rt_nonfinite.h"
#include "rt_nonfinite.h"

/* Function Definitions */
void nanvar(const emxArray_real_T *x, emxArray_real_T *y)
{
  double b_y;
  double r;
  double xbar;
  int i;
  int ix;
  int j;
  int k;
  int n;
  int nn;
  int vstride;
  n = x->size[1] - 1;
  i = y->size[0];
  y->size[0] = x->size[0];
  emxEnsureCapacity_real_T(y, i);
  if (x->size[0] != 0) {
    vstride = x->size[0];
    ix = -1;
    for (j = 0; j < vstride; j++) {
      ix++;
      if (x->size[1] == 0) {
        y->data[j] = rtNaN;
      } else {
        xbar = 0.0;
        nn = 0;
        for (k = 0; k <= n; k++) {
          i = ix + k * vstride;
          if (!rtIsNaN(x->data[i])) {
            xbar += x->data[i];
            nn++;
          }
        }
        if (nn == 0) {
          y->data[j] = rtNaN;
        } else {
          xbar /= (double)nn;
          b_y = 0.0;
          for (k = 0; k <= n; k++) {
            i = ix + k * vstride;
            if (!rtIsNaN(x->data[i])) {
              r = x->data[i] - xbar;
              b_y += r * r;
            }
          }
          if (nn > 1) {
            nn--;
          }
          y->data[j] = b_y / (double)nn;
        }
      }
    }
  }
}

/* End of code generation (nanvar.c) */
