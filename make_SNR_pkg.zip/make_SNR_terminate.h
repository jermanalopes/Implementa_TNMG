/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * make_SNR_terminate.h
 *
 * Code generation for function 'make_SNR_terminate'
 *
 */

#ifndef MAKE_SNR_TERMINATE_H
#define MAKE_SNR_TERMINATE_H

/* Include files */
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void make_SNR_terminate(void);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (make_SNR_terminate.h) */
