/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * make_SNR_emxAPI.h
 *
 * Code generation for function 'make_SNR_emxAPI'
 *
 */

#ifndef MAKE_SNR_EMXAPI_H
#define MAKE_SNR_EMXAPI_H

/* Include files */
#include "make_SNR_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern emxArray_int32_T *emxCreateND_int32_T(int numDimensions,
                                             const int *size);

extern emxArray_int32_T *
emxCreateWrapperND_int32_T(int *data, int numDimensions, const int *size);

extern emxArray_int32_T *emxCreateWrapper_int32_T(int *data, int rows,
                                                  int cols);

extern emxArray_int32_T *emxCreate_int32_T(int rows, int cols);

extern void emxDestroyArray_int32_T(emxArray_int32_T *emxArray);

extern void emxInitArray_int32_T(emxArray_int32_T **pEmxArray,
                                 int numDimensions);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (make_SNR_emxAPI.h) */
