/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * make_SNR.c
 *
 * Code generation for function 'make_SNR'
 *
 */

/* Include files */
#include "make_SNR.h"
#include "make_SNR_types.h"

/* Function Definitions */
void make_SNR(double resolution_microV, double fs, const emxArray_int32_T *ecg,
              double *R_pos, double *SNR)
{
  (void)resolution_microV;
  (void)fs;
  (void)ecg;
  *R_pos = 0.0;
  *SNR = 0.0;
  /*     [R_pos,thr,vcg] = ECG_peak_detect_mod_with_derivative(ecg_tmp,fs);
   * %calcula os picos em R */
  /*     [beats,beats_av,group,offset,beats_vcg,beats_vcg_av,SNR,R_pos]=average_beats_v5(ecg_tmp,R_pos,fs,vcg);
   * %calcula SNR */
}

/* End of code generation (make_SNR.c) */
