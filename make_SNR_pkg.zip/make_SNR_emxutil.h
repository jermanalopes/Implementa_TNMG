/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * make_SNR_emxutil.h
 *
 * Code generation for function 'make_SNR_emxutil'
 *
 */

#ifndef MAKE_SNR_EMXUTIL_H
#define MAKE_SNR_EMXUTIL_H

/* Include files */
#include "make_SNR_types.h"
#include "rtwtypes.h"
#include <stddef.h>
#include <stdlib.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Function Declarations */
extern void emxFree_int32_T(emxArray_int32_T **pEmxArray);

extern void emxInit_int32_T(emxArray_int32_T **pEmxArray, int numDimensions);

#ifdef __cplusplus
}
#endif

#endif
/* End of code generation (make_SNR_emxutil.h) */
