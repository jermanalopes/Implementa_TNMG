/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * make_SNR_data.c
 *
 * Code generation for function 'make_SNR_data'
 *
 */

/* Include files */
#include "make_SNR_data.h"

/* End of code generation (make_SNR_data.c) */
