/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * make_SNR_terminate.c
 *
 * Code generation for function 'make_SNR_terminate'
 *
 */

/* Include files */
#include "make_SNR_terminate.h"

/* Function Definitions */
void make_SNR_terminate(void)
{
  /* (no terminate code required) */
}

/* End of code generation (make_SNR_terminate.c) */
