/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * make_SNR_initialize.c
 *
 * Code generation for function 'make_SNR_initialize'
 *
 */

/* Include files */
#include "make_SNR_initialize.h"

/* Function Definitions */
void make_SNR_initialize(void)
{
}

/* End of code generation (make_SNR_initialize.c) */
